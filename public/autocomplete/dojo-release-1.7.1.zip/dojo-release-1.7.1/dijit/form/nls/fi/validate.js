//>>built
define(
//begin v1.x content
({
	invalidMessage: "Annettu arvo ei kelpaa.",
	missingMessage: "Tämä arvo on pakollinen.",
	rangeMessage: "Tämä arvo on sallitun alueen ulkopuolella."
})
//end v1.x content
);
