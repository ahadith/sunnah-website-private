//>>built
define(
//begin v1.x content
({
		previousMessage: "Edelliset valinnat",
		nextMessage: "Lisää valintoja"
})
//end v1.x content
);
