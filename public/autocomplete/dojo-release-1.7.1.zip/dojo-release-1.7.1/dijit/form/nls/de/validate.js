//>>built
define(
//begin v1.x content
({
	invalidMessage: "Der eingegebene Wert ist ungültig. ",
	missingMessage: "Dieser Wert ist erforderlich.",
	rangeMessage: "Dieser Wert liegt außerhalb des gültigen Bereichs. "
})
//end v1.x content
);
