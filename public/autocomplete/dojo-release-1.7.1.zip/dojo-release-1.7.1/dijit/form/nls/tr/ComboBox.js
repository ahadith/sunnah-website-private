//>>built
define(
//begin v1.x content
({
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
})
//end v1.x content
);
