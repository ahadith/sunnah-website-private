//>>built
define(
//begin v1.x content
({
	invalidMessage: "El valor introduït no és vàlid",
	missingMessage: "Aquest valor és necessari",
	rangeMessage: "Aquest valor és fora de l'interval"
})

//end v1.x content
);
