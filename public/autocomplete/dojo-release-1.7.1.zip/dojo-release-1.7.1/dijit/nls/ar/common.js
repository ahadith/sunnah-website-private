//>>built
define(
//begin v1.x content
({
	buttonOk: "حسنا",
	buttonCancel: "الغاء",
	buttonSave: "حفظ",
	itemClose: "اغلاق"
})
//end v1.x content
);
