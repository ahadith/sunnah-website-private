//>>built
define(
//begin v1.x content
({
	loadingState: "Жүктелуде...",
	errorState: "Кешіріңіз, қате орын алды"
})
//end v1.x content
);
