//>>built
define(
//begin v1.x content
({
	loadingState: "טעינה...‏",
	errorState: "אירעה שגיאה"
})
//end v1.x content
);
